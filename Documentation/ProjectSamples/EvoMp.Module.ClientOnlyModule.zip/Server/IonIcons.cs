using EvoMp.Core.Module.Server;

namespace EvoMp.Module.Ionicons.Server
{
    public class IonIcons : BaseModule, IIonIcons
    {
    }
}
