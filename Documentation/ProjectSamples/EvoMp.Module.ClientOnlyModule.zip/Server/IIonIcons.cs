using EvoMp.Core.Module.Server;

namespace EvoMp.Module.Ionicons.Server
{
    [ModuleProperties("shared", "Sascha", "Module for Ionic Icons.")]
    public interface IIonIcons
    {
    }
}
