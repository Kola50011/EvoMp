using EvoMp.Core.Module.Server;

namespace $safeprojectname$.Server
{
    [ModuleProperties("shared", "James, Ruffo", "Module for testing.")]
    public interface ITestModule
    {
    }
}
