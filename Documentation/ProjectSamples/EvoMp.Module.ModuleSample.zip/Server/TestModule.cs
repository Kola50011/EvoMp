using EvoMp.Module.CommandHandler.Server;
using EvoMp.Module.MessageHandler.Server;
using $safeprojectname$.Server.Debuging;
using EvoMp.Module.VehicleHandler.Server;
using GrandTheftMultiplayer.Server.API;

namespace $safeprojectname$.Server
{
    public class TestModule : ITestModule
    {
        private readonly API _api;
        private readonly IMessageHandler _messageHandler;
        private readonly IVehicleHandler _vehicleHandler;
        public CommandHelp CommandHelp;
        public ExtendedVehicleTest ExtendedVehicleTest;
        public LoginFucker LoginFucker;
        public VehicleCommands VehicleCommands;

        public TestModule(API api, ICommandHandler commandHandler, IVehicleHandler vehicleHandler,
            IMessageHandler messageHandler)
        {
            _api = api;
            _vehicleHandler = vehicleHandler;
            _messageHandler = messageHandler;
            LoginFucker = new LoginFucker(api, messageHandler);
            CommandHelp = new CommandHelp(api, commandHandler, messageHandler);
            ExtendedVehicleTest = new ExtendedVehicleTest(api, vehicleHandler, messageHandler);

            VehicleCommands = new VehicleCommands(api, vehicleHandler);
        }
    }
}
